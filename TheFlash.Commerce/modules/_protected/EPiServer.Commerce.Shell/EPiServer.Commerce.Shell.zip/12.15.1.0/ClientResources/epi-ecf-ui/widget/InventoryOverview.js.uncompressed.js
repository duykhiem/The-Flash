require({cache:{
'url:epi-ecf-ui/widget/templates/InventoryOverview.html':"﻿<div class=\"epi-listingOverview\">\r\n    <div data-dojo-attach-point=\"header\">\r\n        <div data-dojo-type=\"epi-cms/contentediting/NotificationBar\" data-dojo-attach-point=\"notificationBar\"></div>\r\n        <div class=\"epi-view-container\">\r\n            <h1 data-dojo-attach-point=\"heading\" class=\"dijitInline\">${resources.heading}</h1>\r\n            <div>\r\n                <button class=\"epi-mediumButton\"\r\n                        data-dojo-attach-event='onClick: _onShowNewItem'\r\n                        data-dojo-attach-point=\"addNewItem\"\r\n                        data-dojo-type=\"dijit/form/Button\"\r\n                        data-dojo-props=\"label: '${resources.buttons.addinventory}', title:'${resources.buttons.addinventory}', iconClass:'epi-iconPlus'\"></button>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <div data-dojo-attach-point=\"listNode\"></div>\r\n    <div data-dojo-attach-point='addInventoryNode' class=\"dijitContentPane\">\r\n        <div data-dojo-attach-point='newItemFormNode'></div>\r\n        <div class=\"epi-floater--right\">\r\n            <button class=\"epi-mediumButton Salt\"\r\n                    data-dojo-attach-event='onClick: _onAddNewInventory'\r\n                    data-dojo-type=\"dijit/form/Button\"\r\n                    data-dojo-props=\"label: '${sharedResources.action.save}', title:'${sharedResources.action.save}'\"></button>\r\n            <button class=\"epi-mediumButton\"\r\n                    data-dojo-attach-event='onClick: _onCancelNewItem'\r\n                    data-dojo-type=\"dijit/form/Button\"\r\n                    data-dojo-props=\"label: '${sharedResources.action.cancel}', title:'${sharedResources.action.cancel}'\"></button>\r\n        </div>\r\n    </div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/InventoryOverview", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/dom",
    "dojo/dom-construct",
    "dojo/dom-geometry",
    "dojo/dom-style",

// dijit
    "dijit/form/Select",

// dojox
    "dojox/html/entities",

// EPi CMS
    "epi-cms/contentediting/NotificationBar", // used in template

// commerce
    "./_OverviewBase",
    "./NewInventory",
    "../contentediting/editors/InventoryOverviewEditor",
    "./viewmodel/InventoryOverviewModel",

// Resources
    "epi/i18n!epi/cms/nls/commerce.widget.inventoryoverview",
    "epi/i18n!epi/nls/episerver.shared",
    "dojo/text!./templates/InventoryOverview.html"

], function (
// dojo
    array,
    declare,
    dom,
    domConstruct,
    domGeo,
    domStyle,

// dijit
    Select,

// dojox
    entities,

// EPi CMS
    NotificationBar,

// commerce
    _OverviewBase,
    NewInventory,
    InventoryOverviewEditor,
    InventoryOverviewModel,

// Resources
    resources,
    sharedResources,
    template
) {

    return declare([_OverviewBase], {
        // summary:
        //    Represents the widget to preview inventory for entries.
        // tags:
        //    public
        resources: resources,

        sharedResources: sharedResources,

        templateString: template,

        modelClassName: InventoryOverviewModel,

        metadata: null,

        listType: InventoryOverviewEditor,

        metadataTypeName: "EPiServer.Commerce.Shell.ObjectEditing.InternalMetadata.InventoryRecordModel",

        _backToPreviousViewNotification: null,

        newItemWidgetType: NewInventory,

        _validationMessage: null,

        layout: function () {
            // summary:
            //      Layout the inventory overview editor.
            // tags:
            //      protected

            this.inherited(arguments);

            var headerSize = domGeo.getMarginBox(this.header);
            var height = this._contentBox.h - headerSize.h,
                width = this._contentBox.w;

            domStyle.set(this.addInventoryNode, "width", width + "px");
            domStyle.set(this.addInventoryNode, "height", height + "px");
        },

        _showNewItemView: function (show) {
            this.heading.innerHTML = show ? this.resources.buttons.addinventory : this.resources.heading;
            domStyle.set(this.addInventoryNode, "display", show ? "" : "none");
            domStyle.set(this.addNewItem.domNode, "display", show ? "none" : "");
            domStyle.set(this.listNode, "display", show ? "none" : "");
            if (this.newItemWidget) {
                this.newItemWidget.destroy();
                this.newItemWidget = null;
            }
            if (show) {
                this._createNewItemWidget();
                this._showNewItemNotification();
            } else {
                this._backToPreviousViewNotification.showNotification();
            }
        },

        _onAddNewInventory: function() {
            if (this.newItemWidget.isValid()) {
                var newInventory = this.newItemWidget.get("value");
                newInventory.contentLink = this.list.get("value");

                this.list.model.getAllItems(newInventory.contentLink).then(function (items) {
                    for (var i = 0; i < items.length; i++) {
                        if (items[i].warehouseCode === newInventory.warehouseCode) {
                            this._addLocationValidationNotification(items[i].warehouseName);
                            return;
                        }
                    }

                    this._removeLocationValidationNotification();
                    this.list.model.addItem(newInventory);
                    this._showNewItemView(false);
                }.bind(this));
            }
        },

        _onCancelNewItem: function () {
            this._removeLocationValidationNotification();
            this.inherited(arguments);
        },

        _addLocationValidationNotification: function (location) {
            this._removeLocationValidationNotification();

            this._validationMessage = {
                content: resources.existinglocationvalidation + " " + location
            };

            this.notificationBar.add(this._validationMessage);
        },

        _removeLocationValidationNotification: function () {
            if (this._validationMessage) {
                this.notificationBar.remove(this._validationMessage);
            }
        }
    });
});

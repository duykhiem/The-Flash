﻿define("epi-ecf-ui/widget/MarketSelector", [
    // dojo
    "dojo/_base/declare",
    // dijit
    "dijit/form/Select",
    // epi
    "epi/dependency"
], function(
    // dojo
    declare,
    // dijit
    Select,
    // epi
    dependency
) {
    return declare([Select], {

        keyProfileSetting: "market",
        addDefaultItem: true,
        excludeCurrencies: true,
        excludeInactive: false,

        postMixInProperties: function () {
            this.inherited(arguments);

            this.labelAttr = "label";
            this.sortByLabel = false;
            this.store = this.store || dependency.resolve("epi.storeregistry").get("epi.commerce.market");
            this.query = { addDefaultItem: this.addDefaultItem, excludeCurrencies: this.excludeCurrencies, excludeInactive: this.excludeInactive };
            this.maxHeight = -1;
        }
    });
});
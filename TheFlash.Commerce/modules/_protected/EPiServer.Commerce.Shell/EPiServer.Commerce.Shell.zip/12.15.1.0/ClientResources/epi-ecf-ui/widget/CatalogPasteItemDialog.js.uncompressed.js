﻿define("epi-ecf-ui/widget/CatalogPasteItemDialog", [
// dojo
    "dojo/_base/declare",
    "dojo/dom-construct",

// dijit
    "dijit/_Widget",

// epi
    "epi",
    "epi/shell/widget/_ActionProviderWidget",
    "epi/shell/widget/dialog/_DialogContentMixin",
    "epi/i18n!epi/cms/nls/commerce.widget.pasteitemdialog"

], function (
// dojo
    declare,
    domConstruct,

// dijit
    _Widget,

// epi
    epi,
    _ActionProviderWidget,
    _DialogContentMixin,
    resources
){
    return declare([_Widget, _ActionProviderWidget, _DialogContentMixin], {

        hideDuplicateOption: false,

        hideMoveOption: false,
        
        hideLinkOption: false,

        title: resources.title,

        buildRendering: function () {
            this.inherited(arguments);

            domConstruct.create("span", { innerHTML: resources.message }, this.domNode);
        },

        getActions: function () {
            // summary:
            //      Overridden from _ActionProvider

            this._actions = [];
            
            if (!this.hideDuplicateOption) {
                this._actions.push({
                    name: "duplicate",
                    label: resources.duplicate,
                    settings: { type: "button" },
                    action: function() {
                        this.executeDialog('duplicate');
                    }.bind(this)
                });
            }
            
            if (!this.hideLinkOption) {
                this._actions.push({
                    name: "link",
                    label: resources.link,
                    settings: { type: "button" },
                    action: function() {
                        this.executeDialog('link');
                    }.bind(this)
                });
            }
            
            if (!this.hideMoveOption) {
                this._actions.push({
                    name: "move",
                    label: resources.move,
                    settings: { type: "button" },
                    action: function() {
                        this.executeDialog('move');
                    }.bind(this)
                });
            }
            
            this._actions.push({
                name: "cancel",
                label: epi.resources.action.cancel,
                settings: { type: "button" },
                action: function () {
                    this.cancelDialog();
                }.bind(this)
            });
            
            return this._actions;
        }
    });
});